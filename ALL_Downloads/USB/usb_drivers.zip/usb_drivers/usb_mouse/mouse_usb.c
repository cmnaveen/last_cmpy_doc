#include <linux/usb.h>
#include <linux/slab.h>
#include <linux/module.h>

MODULE_AUTHOR("R B Jagadeesh");
MODULE_LICENSE("Dual BSD/GPL");

struct mouse_usb {                                                          
    struct usb_device *usbdev;                                                  
    struct usb_interface *ctrl_intf;                                            
    struct usb_interface *in_intf;                                              
    struct usb_interface *out_intf;                                             
    struct usb_host_endpoint *inep;                                             
    struct usb_endpoint_descriptor *inep_des;                                             
    struct usb_host_endpoint *outep;                                            
//    struct urb *inurb[AUD_IN_URBS];                                             
//    struct urb *outurb[AUD_OUT_URBS];                                           
    unsigned int cur_size;                                                      
    unsigned int in_stream:1;                                                   
    unsigned int out_stream:1;                                                  
    spinlock_t in_stream_lock;                                                  
    spinlock_t out_stream_lock;                                                 
};

static struct usb_device_id device_table [] = {
	{ USB_DEVICE(0x046d, 0xc03d)},
	{ }
};

MODULE_DEVICE_TABLE (usb, device_table);

const struct file_operations mouse_fops = {                           
    .owner = THIS_MODULE,                                                   
};

struct usb_class_driver mouse_class = {"mouse_usb",NULL, &mouse_fops, 244};
/*
mouse_class.name = "mouse_usb";
mouse_class.fops = &mouse_fops;
mouse_class.minor_base = 244;
*/

static int mouse_probe (struct usb_interface *interface,
						const struct usb_device_id *usb_id)
{
	printk ("probe called\n");	

	struct usb_device *udev = interface_to_usbdev(interface);
    struct mouse_usb *dev = NULL;
    struct usb_host_interface *iface_desc;
    struct usb_endpoint_descriptor *endpoint;
    int i = 0;
    int retval = -ENODEV;

    if (! udev)
    {
        printk ("udev is NULL");
        return -1;
    }

    dev = kzalloc(sizeof(struct mouse_usb), GFP_KERNEL);
    if (! dev)
    {
       	printk ("cannot allocate memory for struct mouse_usb");
        retval = -ENOMEM;
        return retval;
    }

/*    dev->command = ML_STOP;

    init_MUTEX(&dev->sem);
    spin_lock_init(&dev->cmd_spinlock);
*/
    dev->usbdev = udev;
    dev->in_intf = interface;
    iface_desc = interface->cur_altsetting;

	printk ("no of endpoints %d\n", iface_desc->desc.bNumEndpoints);

    /* Set up interrupt endpoint information. */
    for (i = 0; i < iface_desc->desc.bNumEndpoints; ++i)
    {
        endpoint = &iface_desc->endpoint[i].desc;

		printk ("endpoint address %x\n", endpoint->bEndpointAddress);

        if (((endpoint->bEndpointAddress & USB_ENDPOINT_DIR_MASK) == USB_DIR_IN)
                && ((endpoint->bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) ==
                    USB_ENDPOINT_XFER_INT))
            dev->inep_des = endpoint;

    }
    if (! dev->inep_des)
    {
        printk ("could not find interrupt in endpoint");
        return -1;
    }

    /* We can register the device now, as it is ready. */
    retval = usb_register_dev(interface, &mouse_class);

	if (retval == -EINVAL)
		printk ("usb_register_dev is failed\n");

	return 0;
}

static void mouse_disconnect (struct usb_interface *intf)
{
	printk ("disconnect called");	

}

static struct usb_driver mouse_driver = {
//	.owner = THIS_MODULE,
	.name = "mouse_usb",
	.id_table = device_table,
	.probe = mouse_probe,
	.disconnect = mouse_disconnect,
};

static int __init mouse_usb_init(void)
{
	int result = 0;

	result = usb_register(&mouse_driver);

	if (result)
		printk ( KERN_INFO "usb register failed %d\n", result);
	
	return result;
}

static void __exit mouse_usb_exit(void)
{
	usb_deregister(&mouse_driver);
}

module_init(mouse_usb_init);
module_exit(mouse_usb_exit);
