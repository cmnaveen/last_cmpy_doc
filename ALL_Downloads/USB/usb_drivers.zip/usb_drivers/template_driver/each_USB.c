//char *product;                                                              
//char *manufacturer;                                                         
//char *serial;                                                               

#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb.h>

MODULE_LICENSE("GPL");

static int usb_probe(struct usb_device *dev, void *data)
{

	printk (KERN_INFO "%s",dev->devpath);
	printk (KERN_INFO "%s",dev->product);
	printk (KERN_INFO "%s",dev->manufacturer);
	printk (KERN_INFO "%s",dev->serial);
	return 0;
}

static int __init usb_init(void)
{

	usb_for_each_dev(NULL, usb_probe);
	return 0;
}

static void __exit usb_exit(void)
{

	return 0;
}

module_init(usb_init);
module_exit(usb_exit);
