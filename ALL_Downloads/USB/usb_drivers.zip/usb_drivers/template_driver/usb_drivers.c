#include <linux/module.h>
#include <linux/init.h>
#include <linux/usb.h>
MODULE_LICENSE("GPL");

static int usb_probe(struct usb_interface *intf, const struct usb_device_id *id)
{

	printk (KERN_INFO "i am in probe \n");
	return 0;
}

static const struct usb_device_id usb_table [] = {
	{
		.idVendor		= 0x041e,
		.idProduct		= 0x406c,
	},
	{ }
};


static struct usb_driver usb_inst = {
	.name		= "usb_driv",
	.probe		= usb_probe,
//	.disconnect	= usb_disconnect,
	.id_table	= usb_table,
};

MODULE_DEVICE_TABLE (usb, usb_table);

static int __init usb_init(void)
{

	usb_register(&usb_inst);

	return 0;
}

static void __exit usb_exit(void)
{

	return 0;
}

module_init(usb_init);
module_exit(usb_exit);
