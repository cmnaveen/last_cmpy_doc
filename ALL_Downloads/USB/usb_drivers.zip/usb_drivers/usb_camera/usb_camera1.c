#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/usb.h>
#include <linux/slab.h>
#include <linux/debugfs.h>
#include <media/v4l2-common.h>
#include <media/v4l2-device.h>
#include <linux/videodev2.h>
#include <media/v4l2-ctrls.h>

#define npackets 6
#define NUM_URBS 5

struct dentry *debug_file;
struct dentry *debug_dir;
struct file *f;
int glob = 1;
loff_t pos = 0 ;
mm_segment_t oldfs ;

//char filename[] = "samplefile.yuv";
//FILE *fp;

MODULE_LICENSE ("Dual BSD/GPL");
MODULE_AUTHOR("RB Jagadeesh");                                                  
MODULE_DESCRIPTION("USB Registration Driver");                                  

static struct usb_device_id usb_idtable[] =
{
	{ USB_DEVICE (0x041e, 0x406c)},
	//	.driver_info {}
	{}
};
MODULE_DEVICE_TABLE (usb, usb_idtable);

struct usb_camera_device {
	struct usb_device *udev;                                                    
	struct usb_interface *intf;                                                 
	int intfnum;                                                                
	char name[32];

	struct mutex lock;
	struct v4l2_device vdev;

	struct usb_host_endpoint *ep;                                           
	struct urb *urb[5];
	int urb_size;
	__u8 *status;
}*dev;

void unlink_urbs (void)
{
	int i = 0;

	for (i = 0; i < NUM_URBS; i++) {
		if (usb_unlink_urb (dev->urb[i]) != -EINPROGRESS) 
			printk (KERN_ERR "Failed to unlink URB\n");
	}
}

static ssize_t debug_write (struct file *file, const char *buffer, size_t length, loff_t *offset)
{
	int i = 0;

	if (*offset)                                                              
		return 0;                                                            

	printk (KERN_INFO "%s()\n",__func__);                                             

	if (!(strncmp(buffer, "start", 5))) {                                    
		printk (" Streaming started\n");                        

		for (i = 0; i < NUM_URBS; i++) {
			if (usb_submit_urb (dev->urb[i], GFP_ATOMIC) < 0) 
				printk (KERN_ERR "Failed to submit URB\n");
		}
		return 5;
	} else if (!(strncmp(buffer, "stop", 4))) {                                
		printk ("Streaming stopped\n");                 
		unlink_urbs ();
		return 4;
	}

	return 0;
}

static void copy_video_data_to_file (void *ptr, int size)
{
	//	fwrite (ptr, size, 1, fp);

	vfs_write (f ,ptr ,size ,&pos) ;

}

static void urb_status_complete (struct urb *urb)                                
{                                                                               
	struct usb_camera_device *dev = urb->context;                                      
	int ret;                                                               

	switch (urb->status) {                                                      
		case 0:                                                                     
			break;                                                                  

		case -ENOENT:       /* usb_kill_urb() called. */                            
		case -ECONNRESET:   /* usb_unlink_urb() called. */                          
		case -ESHUTDOWN:    /* The endpoint is being disabled. */                   
		case -EPROTO:       /* Device is disconnected (reported by some             
							 * host controller). */                                         
			return;                                                                 

		default:                                                                    
			printk (KERN_WARNING "Non-zero status (%d)\n", urb->status);                              
			return;                                                                 
	}                                                                           

	copy_video_data_to_file (urb->transfer_buffer, urb->actual_length);

	/* Resubmit the URB. */                                                     
	urb->interval = dev->ep->desc.bInterval;

	if ((ret = usb_submit_urb (urb, GFP_ATOMIC)) < 0)
		printk(KERN_ERR "Failed to resubmit status URB (%d).\n",ret);                
}

static unsigned int camera_endpoint_max_bpi(struct usb_device *dev,                
		struct usb_host_endpoint *ep)                              
{                                                                               
	u16 psize;                                                                  
	u16 mult;                                                                   

	if (dev && ep) {
		//		printk("Address here %x %x",dev,ep);
		switch (dev->speed) {                                                       
			case USB_SPEED_SUPER:                                                       
			case USB_SPEED_SUPER_PLUS:                                                  
				return le16_to_cpu(ep->ss_ep_comp.wBytesPerInterval);                   
			case USB_SPEED_HIGH:                                                        
				psize = usb_endpoint_maxp(&ep->desc);                                   
				mult = usb_endpoint_maxp_mult(&ep->desc);                               
				return (psize & 0x07ff) * mult;                                         
			case USB_SPEED_WIRELESS:                                                    
				psize = usb_endpoint_maxp(&ep->desc);                                   
				return psize;                                                           
			default:                                                                    
				psize = usb_endpoint_maxp(&ep->desc);                                   
				return psize & 0x07ff;                                                  
		}           	
	} else {
		//		printk("NULL here %x %x",dev,ep);
	}

	return 0;
}

const struct file_operations debug_ops = {                            
	.owner = THIS_MODULE,                                                    
	.write = debug_write,                                                
};

/*
 * static int uvc_init_video_isoc(struct uvc_streaming *stream,                    
 * struct usb_host_endpoint *ep, gfp_t gfp_flags)                              
 */
static int urb_init (struct usb_camera_device *dev)                                     
{                                                                               
	struct usb_host_endpoint *ep = dev->ep;                                 
	unsigned int i, j;                                                
	int pipe;
	int interval;
	u16 psize; 
	u32 size;                                                                   

	psize = camera_endpoint_max_bpi (dev->udev, dev->intf->cur_altsetting->endpoint);                        

	printk (KERN_INFO "packet size %d\n", psize);

	size = npackets * psize;                                                    

	pipe = usb_rcvisocpipe (dev->udev, ep->desc.bEndpointAddress);                

	interval = ep->desc.bInterval;                                              
	if ((interval > 16) && (dev->udev->speed == USB_SPEED_HIGH))                              
		interval = fls(interval) - 1;                                           

	for (i = 0; i < NUM_URBS; ++i) {                                            
		dev->urb[i] = usb_alloc_urb (npackets, GFP_KERNEL);                               
		if (dev->urb[i] == NULL) {                                                      
			return -ENOMEM;                                                     
		}                                                                       

		dev->urb[i]->dev = dev->udev;
		dev->urb[i]->context = dev;
		dev->urb[i]->pipe = pipe;
		dev->urb[i]->interval = interval;
		dev->urb[i]->transfer_flags = URB_ISO_ASAP;
		dev->urb[i]->transfer_buffer = kmalloc (size, GFP_KERNEL);                           

		if (!dev->urb[i]->transfer_buffer) 
			printk(KERN_ERR "Failed to allocate memory");                

		dev->urb[i]->complete = urb_status_complete;
		dev->urb[i]->number_of_packets = npackets;
		dev->urb[i]->transfer_buffer_length = size;

		for (j = 0; j < npackets; j++) {
			dev->urb[i]->iso_frame_desc[j].offset = j * psize;
			dev->urb[i]->iso_frame_desc[j].length = psize;
		}
	}

	return 0;                                                                   
}                                                                               

int parse_interface(struct usb_camera_device *dev)
{
	struct usb_host_interface *alts = dev->intf->cur_altsetting;                

	if (alts->desc.bNumEndpoints == 1) {                            
		struct usb_host_endpoint *ep = &alts->endpoint[0];                      
		struct usb_endpoint_descriptor *desc = &ep->desc;                       

//		printk ("endianess %x %x",le16_to_cpu(desc->wMaxPacketSize),desc->wMaxPacketSize);

		if (le16_to_cpu(desc->wMaxPacketSize) >= 8 && desc->bInterval != 0) {                                             
			printk (KERN_INFO "Found a valid endpoint\n(addr %02x).\n", desc->bEndpointAddress);                      
			dev->ep = ep;                                                   
		}                                                                       

		if ( (ep->desc.bmAttributes & USB_ENDPOINT_XFERTYPE_MASK) 
				== USB_ENDPOINT_XFER_ISOC){
			printk("endpoint is ISOC");
		}

	}

	return 0;
}

int create_debugfs (void)
{
	debug_dir = debugfs_create_dir ("debug_dir", NULL);   

	printk ("%s %d",__func__,__LINE__);
	if (!debug_dir)                                              
		return -ENOENT;                                                  
	printk ("\n Created Directory debug_fs");                        

	debug_file = debugfs_create_file("debug_file", 0644, debug_dir, NULL, &debug_ops);

	if (!debug_file) {                                                
		printk (KERN_ERR "Can't create file\n");
		return -ENOENT;                                                   
	} 

	return 0;
}

static int usb_probe(struct usb_interface *interface, 
		const struct usb_device_id *id)
{
	struct usb_device *udev = interface_to_usbdev(interface);                        

	if (interface->cur_altsetting->desc.bInterfaceNumber != 1) 
		return -1;

	if (id->idVendor && id->idProduct )
		printk (KERN_INFO "Probing known USB device %s " "(%04x:%04x)\n", 
				udev->devpath, id->idVendor,id->idProduct);                     
	else{                                                                        
		printk (KERN_INFO "Probing generic USB device %s\n", udev->devpath);
		//		return -1;	
	}

	if (0 != (usb_set_interface (udev, 1, 4) )) {
		printk (KERN_INFO "can't set 1,4 interface\n");
		return -1;
	}

	printk("current alt_setting %d num of altsets %d", 
			interface->cur_altsetting->desc.bAlternateSetting,interface->num_altsetting);

	if ( interface->cur_altsetting->string)
		printk("string %s", interface->cur_altsetting->string);
	else 
		printk("NULL string");

	/* Allocate memory for the device and initialize it. */                     
	if ((dev = (struct usb_camera_device *) kzalloc 
				(sizeof(struct usb_camera_device), GFP_KERNEL)) == NULL)                       
		return -ENOMEM;

	//mutex_init (&dev->lock);                                                     

	dev->udev = usb_get_dev(udev);                                              
	dev->intf = usb_get_intf(interface);                                             
	dev->intfnum = interface->cur_altsetting->desc.bInterfaceNumber;

	if (udev->product != NULL)                                                  
		strlcpy (dev->name, udev->product, strlen( udev->product));  
	else                                                                        
		snprintf (dev->name, strlen (dev->name), "USB_Camera (%04x:%04x)", 
				le16_to_cpu(udev->descriptor.idVendor),                             
				le16_to_cpu(udev->descriptor.idProduct));

	parse_interface(dev);

	//	if (v4l2_device_register(&interface->dev, &dev->vdev) < 0)
	//		goto error;

	//	usb_set_intfdata (interface, dev);

	urb_init (dev);
	create_debugfs();

	oldfs = get_fs() ;

	set_fs(KERNEL_DS) ;

	f = filp_open ( "/tmp/data" , O_CREAT | O_APPEND, 0640) ;
	if ( IS_ERR(f) || f == NULL ) {
		printk ("file opening fasiled\n") ;
		return -1 ;
	}

	return 0;
}

static void usb_disconnect(struct usb_interface *interface)                       
{
	unlink_urbs ();
//	usb_set_interface(dev->usbdev, 1, 0);                                   
	printk (KERN_INFO "logi camera removed\n");
} 

static struct usb_driver usb_camera =
{
	.name = "usb_camera",
	.id_table = usb_idtable,
	.probe = usb_probe,
	.disconnect = usb_disconnect,
};

static int __init usb_init (void)
{

	return usb_register(&usb_camera);
}

static void __exit usb_exit (void)
{
	set_fs(oldfs) ;

	debugfs_remove (debug_file);
	debugfs_remove (debug_dir);
	usb_deregister (&usb_camera);
}

module_init (usb_init);
module_exit (usb_exit);
